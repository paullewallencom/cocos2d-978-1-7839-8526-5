var s_SpriteSheetImg = "res/dhtex.png";
var s_SpriteSheetPlist = "res/dhtex.plist"
var s_Flap_mp3 = "res/flap.mp3";
var s_Crash_mp3 = "res/crash.mp3"

var g_resources = [
    s_SpriteSheetImg,
    s_SpriteSheetPlist,
    s_Flap_mp3,
    s_Crash_mp3
];