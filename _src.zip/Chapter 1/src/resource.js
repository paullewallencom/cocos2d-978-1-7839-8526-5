var s_Play = "res/play_button.png";
var s_Pause = "res/pause_button.png";
var s_Tile = "res/tile.png";

var g_resources = [
    //image
    s_Play,
    s_Pause,
    s_Tile

    //plist

    //fnt

    //tmx

    //bgm

    //effect
];